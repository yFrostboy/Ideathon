// Telas, mapa e simulação do ônibus (várias linhas).
let linhas, linha, pontos, acum, total, velocidadeMs;
let mapa, rota, marcadorOnibus, marcadorPonto, pontoAtual, timer;
let s = 0; // metros já percorridos pelo ônibus simulado

const $ = (id) => document.getElementById(id);

async function carregar() {
  linhas = await fetch('data/linhas.json').then((r) => r.json());
  $('linha').innerHTML = linhas
    .map((l, i) => `<option value="${i}">${l.nome}</option>`)
    .join('');
  escolherLinha();
}

// Roda ao abrir o site e toda vez que a pessoa troca a linha
function escolherLinha() {
  linha = linhas[$('linha').value];
  pontos = linha.pontos;
  acum = distanciasAcumuladas(linha.trajeto);
  total = acum[acum.length - 1];
  velocidadeMs = linha.velocidade_kmh / 3.6;
  $('ponto').innerHTML = pontos
    .map((ponto, i) => `<option value="${i}">${ponto.nome}</option>`)
    .join('');
}

function mostrar(id) {
  $('tela-inicio').hidden = id !== 'tela-inicio';
  $('tela-mapa').hidden = id !== 'tela-mapa';
}

function icone(emoji) {
  return L.divIcon({ html: emoji, className: 'icone', iconSize: [30, 30] });
}

function criarMapa() {
  const centro = [-21.2087, -50.4328];
  mapa = L.map('mapa').setView(centro, 14);
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
  }).addTo(mapa);
  marcadorOnibus = L.marker(centro, { icon: icone('🚌') }).addTo(mapa);
  marcadorPonto = L.marker(centro, { icon: icone('🧍') }).addTo(mapa);

  // Ajuda para traçar o trajeto: abra o site com ?captura e clique no mapa.
  // As coordenadas aparecem no Console do navegador (F12).
  if (location.search.includes('captura')) {
    mapa.on('click', (e) =>
      console.log(`[${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)}],`)
    );
  }
}

// Desenha o trajeto da linha escolhida (apaga o da linha anterior)
function desenharLinha() {
  if (rota) rota.remove();
  rota = L.polyline(linha.trajeto, { color: '#14213d', weight: 5 }).addTo(mapa);
  mapa.fitBounds(rota.getBounds());
}

function atualizar() {
  marcadorOnibus.setLatLng(posicaoNoTrajeto(linha.trajeto, acum, s));
  const chega = minutosAteOPonto(s, acum[pontoAtual.indice], total, velocidadeMs);
  const caminhada = Number($('caminhada').value) || 0;
  const sai = chega - caminhada;

  $('chega').textContent = `Chega em ${Math.ceil(chega)} min`;
  $('caminha').textContent = `Caminhada: ${caminhada} min`;
  $('saida').textContent = sai > 1 ? `Saia em ${Math.floor(sai)} min` : 'Saia agora!';
}

function passo() {
  s = (s + velocidadeMs) % total; // anda 1 segundo
  atualizar();
}

function ver() {
  pontoAtual = pontos[$('ponto').value];
  mostrar('tela-mapa');
  if (!mapa) criarMapa();
  mapa.invalidateSize();
  desenharLinha();
  s = 0;
  marcadorPonto.setLatLng(linha.trajeto[pontoAtual.indice]);
  $('titulo-mapa').textContent = `${linha.nome} · ${pontoAtual.nome}`;
  clearInterval(timer);
  atualizar();
  timer = setInterval(passo, 1000);
}

$('linha').addEventListener('change', escolherLinha);
$('btn-ver').addEventListener('click', ver);
$('btn-trocar').addEventListener('click', () => {
  clearInterval(timer);
  mostrar('tela-inicio');
});

carregar()
  .then(() => { $('btn-ver').disabled = false; })
  .catch(() => {
    $('btn-ver').insertAdjacentHTML('afterend',
      '<p class="aviso">Não foi possível carregar os dados. Abra o site pelo Live Server ou pelo link do GitHub Pages, e não clicando duas vezes no arquivo.</p>');
  });