// Cálculos da previsão (não mexem na tela). Precisam do Leaflet carregado antes.

// Distância em metros entre dois pontos [lat, lng]
function distanciaM(a, b) {
  return L.latLng(a).distanceTo(L.latLng(b));
}

// Para cada ponto do trajeto, quantos metros se andou desde o início
function distanciasAcumuladas(trajeto) {
  const acum = [0];
  for (let i = 1; i < trajeto.length; i++) {
    acum.push(acum[i - 1] + distanciaM(trajeto[i - 1], trajeto[i]));
  }
  return acum;
}

// Posição [lat, lng] do ônibus depois de andar s metros pelo trajeto
function posicaoNoTrajeto(trajeto, acum, s) {
  let i = 1;
  while (i < acum.length - 1 && acum[i] < s) i++;
  const t = (s - acum[i - 1]) / (acum[i] - acum[i - 1]);
  const [lat1, lng1] = trajeto[i - 1];
  const [lat2, lng2] = trajeto[i];
  return [lat1 + (lat2 - lat1) * t, lng1 + (lng2 - lng1) * t];
}

// Minutos até o ônibus chegar ao ponto (a linha é circular: ao fim, volta ao início)
function minutosAteOPonto(s, distanciaDoPonto, total, velocidadeMs) {
  let falta = distanciaDoPonto - s;
  if (falta < 0) falta += total;
  return falta / velocidadeMs / 60;
}