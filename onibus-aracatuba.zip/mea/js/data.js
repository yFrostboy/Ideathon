// Dados da simulação. Edite aqui para ajustar a linha, as paradas e o ponto padrão.
// As coordenadas são aproximadas (Araçatuba-SP): troque por pontos reais da linha quando tiver.
window.DATA = {
  center: [-21.2125, -50.4420],
  line: { number: "04", from: "Bairro", to: "Centro" },
  // o primeiro ponto é a garagem (de onde o ônibus sai); os demais são as paradas
  waypoints: [[-21.2240,-50.4560],[-21.2215,-50.4525],[-21.2180,-50.4470],[-21.2140,-50.4410],[-21.2112,-50.4365],[-21.2090,-50.4330]],
  stops: [
    { name: "Terminal Jardim Paulista", at: 1 },
    { name: "Av. dos Araçás, 310",      at: 2 },
    { name: "Av. dos Araçás, 842",      at: 3 },
    { name: "Praça da Vila Mendonça",   at: 4 },
    { name: "Centro",                   at: 5 }
  ],
  defaultStop: 2,      // parada de embarque inicial (posição na lista acima)
  walkMinutes: 5,      // tempo de caminhada até o ponto
  startEtaMinutes: 8   // previsão inicial do ônibus para a parada padrão
};
