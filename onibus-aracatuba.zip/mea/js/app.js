(function () {
  "use strict";
  var D = window.DATA;
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  var reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  var map = null, S = null, alertsOn = false, toastTimer, sel = D.defaultStop, markers = [];
  var NEAR = 150; // metros: dentro disso o ônibus "chegou"

  try { var saved = parseInt(localStorage.getItem("mea.stop"), 10); if (saved >= 0 && saved < D.stops.length) sel = saved; } catch (e) {}

  function toast(msg) {
    var t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2200);
  }
  function plural(n, one, many) { return n + " " + (n === 1 ? one : many); }

  /* ---------- abas ---------- */
  function show(id, save) {
    if (!document.getElementById(id)) id = "mapa";
    $$(".view").forEach(function (v) { v.classList.toggle("on", v.id === id); });
    $$("[data-tab]").forEach(function (b) { b.setAttribute("aria-selected", b.dataset.tab === id); });
    if (id === "mapa" && map) setTimeout(function () { map.invalidateSize(); }, 50);
    if (save !== false) history.replaceState(null, "", "#" + id);
  }
  $$("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { show(b.dataset.tab); }); });
  $("#gomap").addEventListener("click", function () { show("mapa"); });
  addEventListener("hashchange", function () { show(location.hash.slice(1), false); });

  /* ---------- perfil ---------- */
  $("#sw").addEventListener("click", function () {
    alertsOn = this.getAttribute("aria-checked") !== "true";
    this.setAttribute("aria-checked", alertsOn);
    toast(alertsOn ? "Alertas de embarque ativados" : "Alertas de embarque desativados");
    if (alertsOn && "Notification" in window && Notification.permission === "default") Notification.requestPermission();
  });
  $("#prefs").addEventListener("click", function () { toast("Preferências em breve"); });
  $("#bell").addEventListener("click", function () { this.classList.remove("has"); toast("Sem novos avisos"); });

  /* ---------- lista de paradas ---------- */
  function etaLabel(i) {
    if (!S) return "";
    var delta = S.stopD[i] - S.d;
    if (delta < -NEAR) return { t: "já passou", past: true };
    if (delta <= NEAR) return { t: "chegou", past: false };
    return { t: "chega em " + Math.ceil(delta / S.speed / 60) + " min", past: false };
  }
  function drawStops() {
    $("#stoplist").innerHTML = D.stops.map(function (s, i) {
      var e = etaLabel(i) || { t: "", past: false };
      return "<li class='" + (i === sel ? "sel" : "") + "'><button class='card stopbtn' data-i='" + i + "' aria-pressed='" + (i === sel) + "'>" +
        "<span><small>Parada " + (i + 1) + "</small><b>" + s.name + (i === sel ? "<span class='mine'><svg width='12' height='12'><use href='#i-check'/></svg>Seu ponto</span>" : "") + "</b></span>" +
        "<span class='eta2" + (e.past ? " past" : "") + "'>" + e.t + "</span></button></li>";
    }).join("");
  }
  $("#stoplist").addEventListener("click", function (ev) {
    var b = ev.target.closest("[data-i]"); if (b) selectStop(+b.dataset.i);
  });
  function selectStop(i) {
    sel = i;
    try { localStorage.setItem("mea.stop", i); } catch (e) {}
    if (S) { S.warned = false; styleMarkers(); S.render(); }
    drawStops();
    toast("Seu ponto: " + D.stops[i].name);
  }
  drawStops();

  /* ---------- mapa ---------- */
  function stopIcon(me) { return L.divIcon({ className: "", html: "<div class='stopdot" + (me ? " me" : "") + "'></div>", iconSize: [16, 16] }); }
  function styleMarkers() {
    markers.forEach(function (m, i) {
      m.setIcon(stopIcon(i === sel)); m.unbindTooltip();
      m.bindTooltip(i === sel ? "Seu ponto" : D.stops[i].name, { className: "lbl", direction: "right", offset: [10, 0], permanent: i === sel });
    });
  }
  if (typeof L === "undefined") { $("#maperr").hidden = false; }
  else {
    map = L.map("map", { zoomControl: false }).setView(D.center, 14);
    L.control.zoom({ position: "topright", zoomInTitle: "Aproximar", zoomOutTitle: "Afastar" }).addTo(map);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19, attribution: "&copy; <a href='https://www.openstreetmap.org/copyright'>OpenStreetMap</a>"
    }).addTo(map);
    getRoute().then(startSim);
  }

  function getRoute() {
    var fallback = D.waypoints.map(function (p) { return L.latLng(p[0], p[1]); });
    var coords = D.waypoints.map(function (p) { return p[1] + "," + p[0]; }).join(";");
    var ctl = new AbortController(), to = setTimeout(function () { ctl.abort(); }, 5000);
    return fetch("https://router.project-osrm.org/route/v1/driving/" + coords + "?overview=full&geometries=geojson", { signal: ctl.signal })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        clearTimeout(to);
        if (!j.routes || !j.routes[0]) throw 0;
        return j.routes[0].geometry.coordinates.map(function (c) { return L.latLng(c[1], c[0]); });
      })
      .catch(function () { return fallback; }); // sem o roteador: linha reta entre os pontos
  }

  function startSim(path) {
    var cum = [0], k;
    for (k = 1; k < path.length; k++) cum.push(cum[k - 1] + path[k - 1].distanceTo(path[k]));
    var total = cum[cum.length - 1];
    function nearestD(ll) {
      var best = 0, bd = Infinity;
      path.forEach(function (p, j) { var d = p.distanceTo(ll); if (d < bd) { bd = d; best = j; } });
      return cum[best];
    }
    function pointAt(d) {
      d = Math.max(0, Math.min(total, d));
      for (var j = 1; j < cum.length; j++) if (cum[j] >= d) {
        var f = (d - cum[j - 1]) / ((cum[j] - cum[j - 1]) || 1);
        return L.latLng(path[j - 1].lat + (path[j].lat - path[j - 1].lat) * f, path[j - 1].lng + (path[j].lng - path[j - 1].lng) * f);
      }
      return path[path.length - 1];
    }

    L.polyline(path, { color: "#fff", weight: 11, lineCap: "round" }).addTo(map);
    var line = L.polyline(path, { color: "#2a7551", weight: 6, lineCap: "round" }).addTo(map);
    map.fitBounds(line.getBounds(), { padding: [90, 90] });

    var stopD = D.stops.map(function (s, i) {
      var ll = L.latLng(D.waypoints[s.at][0], D.waypoints[s.at][1]);
      var m = L.marker(ll, { icon: stopIcon(false) }).addTo(map);
      m.on("click", function () { selectStop(i); });
      markers.push(m);
      return nearestD(ll);
    });
    styleMarkers();
    var bus = L.marker(pointAt(0), { zIndexOffset: 1000, icon: L.divIcon({ className: "", html: "<div class='buspin'><svg width='24' height='24'><use href='#i-bus'/></svg></div>", iconSize: [44, 44] }) }).addTo(map);
    bus.bindTooltip("Linha " + D.line.number, { className: "lbl", direction: "right", offset: [26, 0], permanent: true });

    // velocidade do ônibus: a previsão inicial para a parada padrão é a do protótipo (8 min)
    var speed = stopD[D.defaultStop] / (D.startEtaMinutes * 60);
    S = { d: 0, speed: speed, stopD: stopD, warned: false, mult: 10, playing: true, hold: 0, follow: true, lastPan: 0, lastList: 0 };

    S.render = function () {
      var ud = stopD[sel], delta = ud - S.d, etaS = Math.max(0, delta / speed);
      var min = Math.ceil(etaS / 60), arrived = Math.abs(delta) <= NEAR, passed = delta < -NEAR;
      var away = stopD.filter(function (d) { return d > S.d + NEAR && d <= ud; }).length;
      $("#etatxt").innerHTML = passed ? "Seu ônibus <em>já passou</em> por este ponto." :
        arrived ? "Seu ônibus <em>chegou!</em>" : "Seu ônibus chega em <em>" + plural(min, "minuto", "minutos") + ".</em>";
      $("#ring").textContent = passed ? "–" : arrived ? "0" : min;
      $("#prog").style.width = (passed ? 100 : Math.max(0, Math.min(100, S.d / ud * 100))) + "%";
      $("#stops").textContent = passed ? "Aguarde a próxima volta" : arrived ? "No seu ponto" : away <= 1 ? "Ônibus a 1 parada" : "Ônibus a " + away + " paradas";
      $("#addr").textContent = D.stops[sel].name;
      var leave = Math.ceil(etaS / 60 - D.walkMinutes);
      $("#leave").innerHTML = passed ? "<b>Escolha outro ponto</b>" : arrived ? "<b>Embarque agora</b>" : leave <= 0 ? "<b>Saia agora!</b>" : "Saia de casa em <b>" + plural(leave, "minuto", "minutos") + "</b>";
      if (!S.warned && !arrived && !passed && leave <= 0) {
        S.warned = true;
        if (alertsOn) {
          toast("Hora de sair! Seu ônibus chega em " + plural(min, "minuto", "minutos"));
          if ("Notification" in window && Notification.permission === "granted") new Notification("Hora de sair", { body: "O ônibus da Linha " + D.line.number + " está chegando." });
        }
      }
    };
    function resetSim() { S.d = 0; S.hold = 0; S.warned = false; bus.setLatLng(pointAt(0)); S.render(); drawStops(); }

    var last = performance.now();
    (function tick(now) {
      var dt = Math.min((now - last) / 1000, .25); last = now;
      if (S.playing) {
        if (S.hold > 0) { S.hold -= dt; if (S.hold <= 0) resetSim(); }
        else {
          S.d = Math.min(total, S.d + speed * S.mult * dt);
          if (S.d >= total) S.hold = 5;
          bus.setLatLng(pointAt(S.d)); S.render();
          if (now - S.lastList > 800) { S.lastList = now; if ($("#paradas").classList.contains("on")) drawStops(); }
          if (S.follow && now - S.lastPan > 600 && $("#mapa").classList.contains("on")) { map.panTo(bus.getLatLng(), { animate: !reduce, duration: .6 }); S.lastPan = now; }
        }
      }
      requestAnimationFrame(tick);
    })(last);

    $("#play").addEventListener("click", function () {
      S.playing = !S.playing;
      this.setAttribute("aria-label", S.playing ? "Pausar simulação" : "Continuar simulação");
      this.querySelector("use").setAttribute("href", S.playing ? "#i-pause" : "#i-play");
    });
    $("#reset").addEventListener("click", resetSim);
    $("#speed").addEventListener("change", function () { S.mult = +this.value; });
    $("#follow").addEventListener("click", function () {
      S.follow = this.getAttribute("aria-pressed") !== "true";
      this.setAttribute("aria-pressed", S.follow);
      this.querySelector("span").textContent = S.follow ? "Acompanhando" : "Acompanhar";
      toast(S.follow ? "Seguindo o ônibus da Linha " + D.line.number : "Acompanhamento pausado");
      if (S.follow) map.panTo(bus.getLatLng());
    });
    map.on("dragstart", function () { S.lastPan = performance.now() + 4000; });
    S.render(); drawStops();
  }

  show(location.hash.slice(1) || "mapa", false);
})();
