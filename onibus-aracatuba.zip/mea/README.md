# Ônibus Araçatuba · Rastreio da Linha 04

Protótipo navegável feito com HTML, CSS e JavaScript puros (mapa real com Leaflet + OpenStreetMap).

## Como rodar no localhost

Opção 1 (Node.js):
    node server.js
    -> abra http://localhost:3000

Opção 2 (Python):
    python3 -m http.server 3000
    -> abra http://localhost:3000

Precisa de internet para carregar o mapa, o Leaflet e as fontes.

## Simulação
Ao abrir, o ônibus da Linha 04 já anda sozinho até o "Seu ponto". Use pausar, reiniciar e a velocidade (1x, 10x, 30x).
Na aba Paradas, escolha onde vai embarcar: a previsão do mapa passa a contar para esse ponto (também dá para tocar na parada no mapa).
Ative "Alertas de embarque" no Perfil para receber o aviso na hora de sair de casa.

## Onde ajustar
- js/data.js: pontos da linha, paradas, parada padrão, tempo de caminhada.
- css/style.css: visual.
